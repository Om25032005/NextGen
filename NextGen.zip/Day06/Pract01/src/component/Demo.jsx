import React from 'react'
import logo from '../assets/logo.jpg'

function Demo() {
  return (
    <div>
      {/* <h1 className='text-blue-600'>Demo Component</h1> */}
      <img alt='flagImg' src={logo} className='h-[100%] w-[100%]'/>
    </div>
  )
}

export default Demo
