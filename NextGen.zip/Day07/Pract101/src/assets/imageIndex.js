import normalWeight from './normal.jpeg'
import obese from './obese.png'
import overWeight from './overweight.png'
import underWeight from './underweight.jpeg'

export const assets = { 
    normalWeight, 
    obese, 
    overWeight, 
    underWeight
}